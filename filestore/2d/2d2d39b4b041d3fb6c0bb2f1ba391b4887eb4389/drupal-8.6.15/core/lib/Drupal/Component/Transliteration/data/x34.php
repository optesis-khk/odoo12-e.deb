<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'qiu', 'tian', NULL, NULL, 'kua', 'wu', 'yin', NULL, NULL, NULL, NULL, NULL, 'yi', NULL, NULL, NULL,
  0x10 => NULL, NULL, NULL, NULL, NULL, NULL, 'xie', NULL, NULL, NULL, NULL, NULL, 'chou', NULL, NULL, NULL,
  0x20 => NULL, 'nuo', NULL, NULL, 'dan', NULL, NULL, NULL, 'xu', 'xing', NULL, 'xiong', 'liu', 'lin', 'xiang', 'yong',
  0x30 => 'xin', 'zhen', 'dai', 'wu', 'pan', NULL, NULL, 'ma', 'qian', 'yi', 'yin', 'nei', 'cheng', 'feng', NULL, NULL,
  0x40 => NULL, 'zhuo', 'fang', 'ao', 'wu', 'zuo', NULL, 'zhou', 'dong', 'su', 'yi', 'qiong', 'kuang', 'lei', 'nao', 'zhu',
  0x50 => 'shu', NULL, NULL, NULL, 'xu', NULL, NULL, 'shen', 'jie', 'die', 'nuo', 'su', 'yi', 'long', 'ying', 'beng',
  0x60 => NULL, NULL, NULL, 'lan', 'miao', 'yi', 'li', 'ji', 'yu', 'luo', 'chai', NULL, NULL, NULL, 'hun', 'xu',
  0x70 => 'hui', 'rao', NULL, 'zhou', NULL, 'han', 'xi', 'tai', 'yao', 'hui', 'jun', 'ma', 'lue', 'tang', 'yao', 'zhao',
  0x80 => 'zhai', 'yu', 'zhuo', 'er', 'ran', 'qi', 'chi', 'wu', 'han', 'tang', 'se', NULL, 'qiong', 'lei', 'sa', NULL,
  0x90 => NULL, 'kui', 'pu', 'ta', 'shu', 'yang', 'ou', 'tai', NULL, 'mian', 'yin', 'diao', 'yu', 'mie', 'jun', 'niao',
  0xA0 => 'xie', 'you', NULL, NULL, 'che', 'feng', 'lei', 'li', NULL, 'luo', NULL, 'ji', NULL, NULL, NULL, NULL,
  0xB0 => 'quan', NULL, 'cai', 'liang', 'gu', 'mao', NULL, 'gua', 'sui', NULL, NULL, 'mao', 'man', 'quan', 'shi', 'li',
  0xC0 => NULL, 'wang', 'kou', 'du', 'zhen', 'ting', NULL, NULL, 'bing', 'huo', 'dong', 'gong', 'cheng', NULL, 'qin', 'jiong',
  0xD0 => 'lu', 'xing', NULL, 'nan', 'xie', NULL, 'bi', 'jie', 'su', NULL, 'gong', NULL, 'you', 'xing', 'qia', 'pi',
  0xE0 => 'dian', 'fu', 'luo', 'qia', 'qia', 'tang', 'bai', 'gan', 'ci', 'xuan', 'lang', NULL, NULL, 'she', NULL, 'li',
  0xF0 => 'hua', 'tou', 'pian', 'di', 'ruan', 'e', 'qie', 'yi', 'zhuo', 'rui', 'jian', NULL, 'chi', 'chong', 'xi', NULL,
];
